# 🛠️ Инструкции для Leanid - Sprint 0.4.1 Integration

## 📋 Задача
Интегрировать Frontend структуру в репозиторий `Solarpaletten/solarmail`

---

## 🚀 Bash-инструкции для терминала

### **1. Создание новой ветки**

```bash
# Переходим в корень проекта solarmail
cd /path/to/solarmail

# Создаём ветку для Sprint 0.4.1
git checkout -b feature/sprint-0.4.1-frontend-structure

# Проверяем текущую ветку
git branch
```

---

### **2. Копирование Frontend структуры**

```bash
# Копируем frontend директорию из outputs в корень проекта
cp -r /path/to/outputs/frontend ./

# Проверяем структуру
ls -la frontend/
```

---

### **3. Установка зависимостей**

```bash
# Переходим в директорию frontend
cd frontend

# Устанавливаем npm пакеты
npm install

# Ожидаемый результат: установка ~30+ пакетов
# Время установки: 2-5 минут
```

---

### **4. Создание .env файла**

```bash
# Копируем пример environment файла
cp .env.example .env.local

# Редактируем (опционально) для локальной разработки
# nano .env.local
# или
# code .env.local

# По умолчанию API_URL = http://localhost:8000
```

---

### **5. Тестовый запуск**

```bash
# Запускаем dev сервер
npm run dev

# Ожидаемый вывод:
# ▲ Next.js 14.2.5
# - Local:        http://localhost:3000
# - Network:      http://192.168.x.x:3000
# ✓ Ready in 2.5s

# Открываем браузер: http://localhost:3000
# Должен отобразиться Dashboard с mock-данными
```

---

### **6. Проверка работоспособности**

**Тестовые шаги:**
1. ✅ Откройте `http://localhost:3000`
2. ✅ Проверьте редирект на `/dashboard`
3. ✅ Убедитесь, что видны:
   - Header с логотипом SolarMail
   - Sidebar с навигацией
   - Statistics Cards (4 карточки)
   - Email List (3 mock-письма)
   - AI Analyzer View (справа)
4. ✅ Проверьте responsive дизайн (resize окна)
5. ✅ Проверьте hover эффекты на карточках писем

---

### **7. Git коммит и пуш**

```bash
# Возвращаемся в корень проекта
cd ..

# Добавляем все файлы frontend
git add frontend/

# Создаём коммит
git commit -m "feat: Sprint 0.4.1 - Frontend structure

- Add Next.js 14 App Router structure
- Implement TypeScript configuration
- Setup Tailwind CSS + shadcn/ui
- Create layout components (Header, Sidebar)
- Implement mail components (MailList, AnalyzerView, StatsCards)
- Add API client for backend integration
- Configure ESLint + Prettier
- Add comprehensive README_FRONTEND.md

Sprint: 0.4.1
Status: Frontend structure ready for API integration"

# Пушим в удалённый репозиторий
git push origin feature/sprint-0.4.1-frontend-structure
```

---

### **8. Проверка в GitHub**

1. Откройте https://github.com/Solarpaletten/solarmail
2. Убедитесь, что ветка `feature/sprint-0.4.1-frontend-structure` появилась
3. Проверьте файлы в директории `frontend/`
4. Создайте Pull Request в `main` (опционально)

---

## 📊 Структура после интеграции

```
solarmail/
├── backend/
│   └── api/
├── core/
│   └── sync/
└── frontend/              ← НОВАЯ ДИРЕКТОРИЯ
    ├── app/
    ├── components/
    ├── lib/
    ├── public/
    ├── package.json
    ├── tsconfig.json
    └── README_FRONTEND.md
```

---

## ✅ Checklist для проверки

- [ ] Frontend директория скопирована в корень проекта
- [ ] `npm install` выполнен успешно
- [ ] `.env.local` создан
- [ ] `npm run dev` запускается без ошибок
- [ ] Dashboard открывается на `http://localhost:3000`
- [ ] Все компоненты отображаются корректно
- [ ] Git коммит создан
- [ ] Ветка запушена в GitHub
- [ ] Pull Request создан (если требуется)

---

## 🐛 Возможные проблемы

### **Проблема 1: npm install fails**
```bash
# Решение: очистить кэш и переустановить
rm -rf node_modules package-lock.json
npm cache clean --force
npm install
```

### **Проблема 2: Port 3000 уже занят**
```bash
# Решение: использовать другой порт
npm run dev -- -p 3001
```

### **Проблема 3: TypeScript ошибки**
```bash
# Решение: проверить версию Node.js
node --version  # Должно быть >= 18.0.0

# Или пересоздать tsconfig
rm tsconfig.json
npx tsc --init
```

---

## 📞 Контакт

Если возникли вопросы или проблемы:
- Сообщите Dashka через формат: `Leanid=>Dashka`
- Опишите проблему и прикрепите лог ошибки
- Dashka передаст запрос Claude для решения

---

## 🎯 Следующие шаги (Sprint 0.4.2)

После успешной интеграции:
1. Dashka утвердит Pull Request
2. Merge в `main` ветку
3. Начало Sprint 0.4.2 - API Integration
4. Замена mock-данных на реальные API вызовы

---

**Создано:** Claude AI Engineer  
**Для:** Leanid (Архитектор)  
**Sprint:** 0.4.1 - Frontend Structure  
**Дата:** October 26, 2025
